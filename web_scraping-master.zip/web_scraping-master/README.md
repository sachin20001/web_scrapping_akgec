# web_scraping
This is a repo having some awesome scraping codes build using Beautiful Soup
